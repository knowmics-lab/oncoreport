Copyright for portions of code in this directory are held by Taylor Otwell as
part of [Laravel Framework](https://github.com/laravel/framework) and are
provided under the MIT license.
